from flask import Flask, render_template, jsonify, request, send_file
import numpy as np
import pandas as pd
from io import StringIO, BytesIO #Used for writing and retriving String and Bytes data easily
import os
import time
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import AdaBoostRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy import stats

import plotly.graph_objects as go

try:
    from flaml import AutoML
    FLAML_AVAILABLE = True
except ImportError:
    FLAML_AVAILABLE = False

try:
    from xgboost import XGBRegressor
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    from catboost import CatBoostRegressor
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False

try:
    from lightgbm import LGBMRegressor
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
)

app = Flask(__name__)


# ---------------------------------------------------------
# Shared PDF helper
# ---------------------------------------------------------

def build_pdf(title, meta_lines, table_headers=None, table_rows=None, note=None,
              highlight_title=None, highlight_lines=None, chart_images=None):
    """
    Builds a simple, clean PDF report and returns it as BytesIO.

    title           : str, main heading
    meta_lines      : list[str], key stats/summary lines (already formatted, plain text)
    table_headers   : list[str] or None
    table_rows      : list[list] or None
    note            : optional str shown in small italic text at the bottom
    highlight_title : optional str, heading for a highlighted callout box (e.g. a prediction)
    highlight_lines : optional list[str], lines shown inside the highlighted callout box
    """

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Title"],
        fontSize=20,
        textColor=colors.HexColor("#1e293b"),
        spaceAfter=6,
    )

    subtitle_style = ParagraphStyle(
        "ReportSubtitle",
        parent=styles["Normal"],
        fontSize=10,
        textColor=colors.HexColor("#64748b"),
        spaceAfter=18,
    )

    heading_style = ParagraphStyle(
        "SectionHeading",
        parent=styles["Heading2"],
        fontSize=13,
        textColor=colors.HexColor("#1e293b"),
        spaceBefore=10,
        spaceAfter=8,
    )

    body_style = ParagraphStyle(
        "Body",
        parent=styles["Normal"],
        fontSize=11,
        textColor=colors.HexColor("#0f172a"),
        leading=16,
    )

    highlight_title_style = ParagraphStyle(
        "HighlightTitle",
        parent=styles["Normal"],
        fontSize=12,
        textColor=colors.HexColor("#065f46"),
        fontName="Helvetica-Bold",
        spaceAfter=6,
    )

    highlight_body_style = ParagraphStyle(
        "HighlightBody",
        parent=styles["Normal"],
        fontSize=14,
        textColor=colors.HexColor("#065f46"),
        fontName="Helvetica-Bold",
        leading=20,
    )

    note_style = ParagraphStyle(
        "Note",
        parent=styles["Normal"],
        fontSize=8,
        textColor=colors.HexColor("#94a3b8"),
        spaceBefore=14,
    )

    story = []

    story.append(Paragraph(title, title_style))
    story.append(Paragraph("Statistical Analysis Dashboard - Generated Report", subtitle_style))

    story.append(Paragraph("Summary", heading_style))
    for line in meta_lines:
        story.append(Paragraph(line, body_style))

    if highlight_title and highlight_lines:
        story.append(Spacer(1, 14))

        highlight_content = [Paragraph(highlight_title, highlight_title_style)]
        for line in highlight_lines:
            highlight_content.append(Paragraph(line, highlight_body_style))

        highlight_table = Table([[highlight_content]], colWidths=[6.5 * inch])
        highlight_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#dcfce7")),
            ("BOX", (0, 0), (-1, -1), 1.2, colors.HexColor("#16a34a")),
            ("LEFTPADDING", (0, 0), (-1, -1), 16),
            ("RIGHTPADDING", (0, 0), (-1, -1), 16),
            ("TOPPADDING", (0, 0), (-1, -1), 14),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 14),
        ]))
        story.append(highlight_table)

    if chart_images:
        story.append(Spacer(1, 16))
        story.append(Paragraph("Visual Analysis", heading_style))
        from reportlab.platypus import Image as ReportImage
        for chart_title, image_bytes in chart_images:
            story.append(Paragraph(chart_title, body_style))
            img = ReportImage(BytesIO(image_bytes), width=6.5 * inch, height=3.65 * inch)
            story.append(img)
            story.append(Spacer(1, 10))

    if table_headers and table_rows:
        story.append(Spacer(1, 16))
        story.append(Paragraph("Data", heading_style))

        data = [table_headers] + table_rows

        table = Table(data, repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f4f6")]),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        story.append(table)

    if note:
        story.append(Paragraph(note, note_style))

    doc.build(story)
    buffer.seek(0)
    return buffer


def read_csv_df(csv_text):
    if not csv_text or not csv_text.strip():
        raise ValueError("The CSV data is empty. Please paste or upload a CSV first.")

    try:
        df = pd.read_csv(StringIO(csv_text))
    except Exception as e:
        # Any parsing failure (jagged rows, bad quoting, wrong delimiter, etc.)
        # becomes a clean, user-facing message instead of crashing with a 500.
        raise ValueError(
            f"Could not parse the CSV. Please check that every row has the same "
            f"number of columns and that it's comma-separated. (Details: {e})"
        )

    if df.shape[0] == 0 or df.shape[1] == 0:
        raise ValueError("The CSV appears to have no usable rows or columns.")

    try:
        import csv as _csv
        _hdr = [h.strip() for h in next(_csv.reader(StringIO(csv_text)))]
        _dups = sorted({h for h in _hdr if _hdr.count(h) > 1})
        if _dups:
            raise ValueError(f"The CSV has duplicate column names: {', '.join(_dups)}. Please make column names unique.")
    except StopIteration:
        pass

    df.columns = df.columns.str.strip()

    # Guard against duplicate column names after stripping whitespace —
    # this silently breaks column selection later otherwise.
    if df.columns.duplicated().any():
        dupes = ", ".join(sorted(set(df.columns[df.columns.duplicated()])))
        raise ValueError(f"The CSV has duplicate column names: {dupes}. Please make column names unique.")

    return df


def first_numeric_column(df, preferred_name="value"):
    """Returns the column name to use for single-column numeric analysis."""
    if preferred_name in df.columns:
        return preferred_name

    for col in df.columns:
        numeric = pd.to_numeric(df[col], errors="coerce")
        if numeric.notna().sum() > 0:
            return col

    return None


# ---------------------------------------------------------
# Text-to-number feature conversion (TF-IDF)
# ---------------------------------------------------------

def build_feature_matrix(df, independent, max_tfidf_features=5):
    """
    Turns the requested independent columns into a fully numeric feature
    matrix. Columns that are already numeric pass through unchanged.
    Columns that are text (e.g. category names, free text) are converted
    to numbers using TF-IDF, so they can still be used as model inputs.

    Returns:
        X                    : numeric pandas DataFrame ready for a model
        feature_columns       : list of the final numeric column names
                                 (a single text column can expand into several)
        text_columns_vectorized: list of original column names that were
                                 converted via TF-IDF (for a friendly note)
    """
    feature_frames = []
    feature_columns = []
    text_columns_vectorized = []

    for col in independent:
        series = df[col]
        numeric = pd.to_numeric(series, errors="coerce")

        # Treat as numeric if most values convert cleanly; otherwise treat as text.
        if numeric.notna().sum() >= max(1, int(0.8 * len(series))):
            feature_frames.append(numeric.rename(col))
            feature_columns.append(col)
        else:
            text_values = series.astype(str).fillna("")
            vectorizer = TfidfVectorizer(max_features=max_tfidf_features)
            tfidf_matrix = vectorizer.fit_transform(text_values)

            if tfidf_matrix.shape[1] == 0:
                # No usable vocabulary (e.g. all values identical/empty) — skip this column.
                continue

            feature_names = vectorizer.get_feature_names_out()
            tfidf_df = pd.DataFrame(
                tfidf_matrix.toarray(),
                columns=[f"{col}_tfidf_{fn}" for fn in feature_names],
                index=series.index,
            )
            feature_frames.append(tfidf_df)
            feature_columns.extend(tfidf_df.columns.tolist())
            text_columns_vectorized.append(col)

    if not feature_frames:
        raise ValueError("None of the independent variable columns could be used as features.")

    X = pd.concat(feature_frames, axis=1)
    return X, feature_columns, text_columns_vectorized


# ---------------------------------------------------------
# Plotly chart builders
# ---------------------------------------------------------

CHART_LAYOUT_DEFAULTS = dict(
    template="plotly_white",
    height=420,
    margin=dict(l=50, r=30, t=60, b=50),
    font=dict(family="Arial, sans-serif", size=12, color="#1e293b"),
)



def chart_actual_vs_predicted(actual, predicted, title="Actual vs Predicted"):
    actual = np.asarray(actual, dtype=float)
    predicted = np.asarray(predicted, dtype=float)
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=actual, y=predicted, mode="markers", name="Observed Predictions",
        marker=dict(color="#2563eb", size=8),
    ))
    lo = float(min(actual.min(), predicted.min()))
    hi = float(max(actual.max(), predicted.max()))
    fig.add_trace(go.Scatter(
        x=[lo, hi], y=[lo, hi], mode="lines", name="Perfect Prediction",
        line=dict(color="#16a34a", dash="dash"),
    ))
    fig.update_layout(title=title, xaxis_title="Actual", yaxis_title="Predicted", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_regression_scatter_line(df, independent, dependent):
    """Scatter plot with a fitted regression line when there is one numeric X."""
    if len(independent) != 1:
        return None
    col = independent[0]
    x = pd.to_numeric(df[col], errors="coerce")
    y = pd.to_numeric(df[dependent], errors="coerce")
    clean = pd.DataFrame({"x": x, "y": y}).dropna()
    if len(clean) < 2 or clean["x"].nunique() < 2:
        return None
    coef = np.polyfit(clean["x"], clean["y"], 1)
    x_line = np.linspace(clean["x"].min(), clean["x"].max(), 100)
    y_line = coef[0] * x_line + coef[1]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=clean["x"], y=clean["y"], mode="markers", name="Observed Data",
                             marker=dict(color="#2563eb", size=8)))
    fig.add_trace(go.Scatter(x=x_line, y=y_line, mode="lines", name="Regression Line",
                             line=dict(color="#dc2626", width=3)))
    fig.update_layout(title=f"Regression — {dependent} vs {col}",
                      xaxis_title=col, yaxis_title=dependent, **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_model_comparison(results_sorted):
    labels = [r["model_label"] for r in results_sorted]
    r2_vals = [r["r_squared"] if np.isfinite(r["r_squared"]) else 0 for r in results_sorted]
    fig = go.Figure(go.Bar(
        x=labels, y=r2_vals,
        text=[f"{v:.3f}" for v in r2_vals], textposition="outside",
    ))
    fig.update_layout(title="Model Comparison — R² Score (higher is better)",
                      yaxis_title="R² Score", xaxis_title="Model", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_multimodel_scatter(results_sorted):
    fig = go.Figure()
    for r in results_sorted:
        fig.add_trace(go.Scatter(
            x=np.asarray(r["actual"], dtype=float),
            y=np.asarray(r["predicted"], dtype=float),
            mode="markers", name=r["model_label"],
            marker=dict(size=8),
        ))
    all_vals = np.concatenate([np.asarray(r["actual"], dtype=float) for r in results_sorted])
    all_pred = np.concatenate([np.asarray(r["predicted"], dtype=float) for r in results_sorted])
    lo = float(min(all_vals.min(), all_pred.min()))
    hi = float(max(all_vals.max(), all_pred.max()))
    fig.add_trace(go.Scatter(x=[lo, hi], y=[lo, hi], mode="lines",
                             name="Perfect Prediction", line=dict(dash="dash")))
    fig.update_layout(title="Multi-Model Comparison — Actual vs Predicted",
                      xaxis_title="Actual", yaxis_title="Predicted", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_simulation_histogram(simulated, predicted_next):
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=simulated, nbinsx=40, name="Simulated Outcomes"))
    fig.add_vline(x=predicted_next, line_dash="dash", line_width=2,
                  annotation_text=f"Predicted: {predicted_next:.2f}", annotation_position="top")
    fig.update_layout(title="Monte Carlo — Distribution of Simulated Outcomes",
                      xaxis_title="Simulated Value", yaxis_title="Frequency", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_simulation_frequency(values_np, simulated_indices):
    unique, counts = np.unique(values_np, return_counts=True)
    # Show how often original sample values are selected by the bootstrap.
    selected_values = values_np[np.asarray(simulated_indices, dtype=int)]
    u, c = np.unique(selected_values, return_counts=True)
    fig = go.Figure(go.Bar(x=u, y=c, name="Times Selected"))
    fig.update_layout(title="Monte Carlo — Original Sample Usage Frequency",
                      xaxis_title="Original Sample Value", yaxis_title="Times Selected",
                      **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_monte_carlo_paths(simulated_paths):
    fig = go.Figure()
    paths = np.asarray(simulated_paths)
    for i in range(min(100, len(paths))):
        fig.add_trace(go.Scatter(
            x=np.arange(paths.shape[1]), y=paths[i], mode="lines",
            line=dict(width=1), opacity=0.25, showlegend=False
        ))
    if len(paths):
        median = np.median(paths, axis=0)
        p5 = np.percentile(paths, 5, axis=0)
        p95 = np.percentile(paths, 95, axis=0)
        x = np.arange(paths.shape[1])
        fig.add_trace(go.Scatter(x=x, y=p95, mode="lines", name="95th Percentile"))
        fig.add_trace(go.Scatter(x=x, y=median, mode="lines", name="Median"))
        fig.add_trace(go.Scatter(x=x, y=p5, mode="lines", name="5th Percentile"))
    fig.update_layout(title="Monte Carlo — Simulation Paths",
                      xaxis_title="Simulation Step", yaxis_title="Simulated Value",
                      **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_simulation_convergence(simulated):
    n = len(simulated)
    step = max(1, n // 300)
    idx = np.arange(step, n + 1, step)
    cummean = np.cumsum(simulated)[idx - 1] / idx
    fig = go.Figure(go.Scatter(x=idx, y=cummean, mode="lines", name="Cumulative Mean"))
    fig.update_layout(title="Monte Carlo — Convergence of Simulation Mean",
                      xaxis_title="Number of Simulations", yaxis_title="Cumulative Mean",
                      **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_distribution_with_critical_region(test_label, statistic, dof=None, alpha=0.05):
    x = np.linspace(-4.5, 4.5, 400)
    if dof is not None:
        y = stats.t.pdf(x, dof)
        crit = stats.t.ppf(1 - alpha / 2, dof)
        dist_name = f"T-Distribution (df={dof})"
    else:
        y = stats.norm.pdf(x)
        crit = stats.norm.ppf(1 - alpha / 2)
        dist_name = "Standard Normal Distribution"
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=y, mode="lines", name=dist_name))
    left_mask = x <= -crit
    right_mask = x >= crit
    fig.add_trace(go.Scatter(x=x[left_mask], y=y[left_mask], fill="tozeroy",
                             mode="none", name="Rejection Region"))
    fig.add_trace(go.Scatter(x=x[right_mask], y=y[right_mask], fill="tozeroy",
                             mode="none", showlegend=False))
    clipped_stat = float(np.clip(statistic, -4.5, 4.5))
    fig.add_vline(x=clipped_stat, line_width=3,
                  annotation_text=f"Test Statistic = {statistic:.3f}", annotation_position="top")
    fig.update_layout(title=f"{test_label} — Distribution & Test Statistic (α={alpha})",
                      xaxis_title="Test Statistic", yaxis_title="Density", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_group_boxplot(groups_dict, title="Group Comparison"):
    fig = go.Figure()
    for name, values in groups_dict.items():
        fig.add_trace(go.Box(y=values, name=str(name)))
    fig.update_layout(title=title, yaxis_title="Value", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_chisq_observed_expected(contingency, expected):
    categories = [f"{r} / {c}" for r in contingency.index for c in contingency.columns]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=categories, y=contingency.values.flatten(), name="Observed"))
    fig.add_trace(go.Bar(x=categories, y=expected.flatten(), name="Expected"))
    fig.update_layout(barmode="group", title="Chi-Square — Observed vs Expected",
                      xaxis_title="Category", yaxis_title="Count", **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_gradient_cost_function(cost_rows):
    labels = [r["model_label"] for r in cost_rows]
    costs = [r["mse"] for r in cost_rows]
    fig = go.Figure(go.Bar(
        x=labels, y=costs,
        text=[f"{v:.4f}" for v in costs], textposition="outside",
    ))
    fig.update_layout(title="Gradient Model Selection — Cost Function (MSE, lower is better)",
                      xaxis_title="Boosting Model", yaxis_title="Mean Squared Error (Cost)",
                      **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def chart_gradient_convergence(cost_history, model_label):
    fig = go.Figure(go.Scatter(x=np.arange(1, len(cost_history)+1),
                               y=cost_history, mode="lines", name="Validation MSE"))
    fig.update_layout(title=f"{model_label} — Cost Function by Boosting Iteration",
                      xaxis_title="Boosting Iteration", yaxis_title="MSE Cost",
                      **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def _png_from_matplotlib(fig):
    buf = BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    return buf.getvalue()


def pdf_scatter(actual, predicted, title):
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.scatter(actual, predicted, alpha=0.7)
    lo = min(np.min(actual), np.min(predicted)); hi = max(np.max(actual), np.max(predicted))
    ax.plot([lo, hi], [lo, hi], linestyle="--", label="Perfect Prediction")
    ax.set_title(title); ax.set_xlabel("Actual"); ax.set_ylabel("Predicted"); ax.legend()
    return _png_from_matplotlib(fig)


def pdf_regression_line(df, independent, dependent):
    if len(independent) != 1:
        return None
    x = pd.to_numeric(df[independent[0]], errors="coerce")
    y = pd.to_numeric(df[dependent], errors="coerce")
    clean = pd.DataFrame({"x": x, "y": y}).dropna()
    if len(clean) < 2 or clean["x"].nunique() < 2:
        return None
    slope, intercept = np.polyfit(clean["x"], clean["y"], 1)
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.scatter(clean["x"], clean["y"], alpha=0.7, label="Observed Data")
    xs = np.linspace(clean["x"].min(), clean["x"].max(), 100)
    ax.plot(xs, slope * xs + intercept, linewidth=2, label="Regression Line")
    ax.set_title(f"Regression — {dependent} vs {independent[0]}")
    ax.set_xlabel(independent[0]); ax.set_ylabel(dependent); ax.legend()
    return _png_from_matplotlib(fig)


def pdf_boxplot(groups_dict, title):
    fig, ax = plt.subplots(figsize=(8, 4.4))
    box_labels = [str(k) for k in groups_dict.keys()]
    try:
        # Matplotlib 3.9+ renamed 'labels' to 'tick_labels' (old name removed in 3.11)
        ax.boxplot(list(groups_dict.values()), tick_labels=box_labels)
    except TypeError:
        ax.boxplot(list(groups_dict.values()), labels=box_labels)
    ax.set_title(title); ax.set_ylabel("Value")
    return _png_from_matplotlib(fig)


def pdf_hypothesis_curve(test_label, statistic, dof=None, alpha=0.05):
    x = np.linspace(-4.5, 4.5, 400)
    if dof is not None:
        y = stats.t.pdf(x, dof); crit = stats.t.ppf(1-alpha/2, dof)
    else:
        y = stats.norm.pdf(x); crit = stats.norm.ppf(1-alpha/2)
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.plot(x, y, linewidth=2, label="Distribution")
    ax.axvline(-crit, linestyle="--"); ax.axvline(crit, linestyle="--")
    ax.axvline(float(np.clip(statistic, -4.5, 4.5)), linewidth=2,
               label=f"Test statistic = {statistic:.3f}")
    ax.set_title(f"{test_label} — Distribution and Test Statistic")
    ax.set_xlabel("Test Statistic"); ax.set_ylabel("Density"); ax.legend()
    return _png_from_matplotlib(fig)


def pdf_chisq(contingency, expected):
    labels = [f"{r}/{c}" for r in contingency.index for c in contingency.columns]
    obs = contingency.values.flatten(); exp = expected.flatten()
    fig, ax = plt.subplots(figsize=(8, 4.4))
    xpos = np.arange(len(labels)); width = 0.38
    ax.bar(xpos-width/2, obs, width, label="Observed")
    ax.bar(xpos+width/2, exp, width, label="Expected")
    ax.set_xticks(xpos); ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_title("Chi-Square — Observed vs Expected"); ax.set_ylabel("Count"); ax.legend()
    return _png_from_matplotlib(fig)


def _pdf_sim_hist(simulated, predicted_next):
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.hist(simulated, bins=40)
    ax.axvline(predicted_next, linestyle="--", linewidth=2, label="Predicted Next Value")
    ax.set_title("Monte Carlo — Outcome Distribution")
    ax.set_xlabel("Simulated Value"); ax.set_ylabel("Frequency"); ax.legend()
    return _png_from_matplotlib(fig)


def _pdf_sim_frequency(values_np, selected_indices):
    selected = values_np[np.asarray(selected_indices, dtype=int)]
    unique, counts = np.unique(selected, return_counts=True)
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.bar([str(v) for v in unique], counts)
    ax.set_title("Monte Carlo — Original Sample Usage Frequency")
    ax.set_xlabel("Original Sample Value"); ax.set_ylabel("Times Selected")
    ax.tick_params(axis="x", rotation=30)
    return _png_from_matplotlib(fig)


def _pdf_sim_paths(paths):
    paths = np.asarray(paths)
    fig, ax = plt.subplots(figsize=(8, 4.4))
    for i in range(min(50, len(paths))):
        ax.plot(paths[i], linewidth=0.7, alpha=0.25)
    ax.plot(np.median(paths, axis=0), linewidth=2, label="Median")
    ax.set_title("Monte Carlo — Simulation Paths")
    ax.set_xlabel("Future Simulation Step"); ax.set_ylabel("Simulated Value"); ax.legend()
    return _png_from_matplotlib(fig)


def pdf_cost_chart(cost_rows):
    fig, ax = plt.subplots(figsize=(8, 4.4))
    labels = [r["model_label"] for r in cost_rows]
    costs = [r["mse"] for r in cost_rows]
    ax.bar(labels, costs)
    ax.set_title("Gradient Model Selection — Cost Function (MSE)")
    ax.set_ylabel("Mean Squared Error (lower is better)")
    ax.tick_params(axis="x", rotation=20)
    return _png_from_matplotlib(fig)


def pdf_cost_history(cost_history, model_label):
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.plot(np.arange(1, len(cost_history) + 1), cost_history, linewidth=2)
    ax.set_title(f"{model_label} — Cost Function Across Boosting Iterations")
    ax.set_xlabel("Boosting Iteration")
    ax.set_ylabel("Validation MSE Cost")
    return _png_from_matplotlib(fig)


# Dark circular line-icon badges (replace emojis in server-generated HTML)
def _badge(paths):
    return (
        "<span class='ui-icon' style='display:inline-flex; width:20px; height:20px; "
        "border-radius:50%; background:#000; border:1px solid rgba(255,255,255,.35); "
        "align-items:center; justify-content:center; vertical-align:middle; margin:0 6px 0 2px;'>"
        "<svg viewBox='0 0 24 24' width='11' height='11' fill='none' stroke='#fff' "
        "stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'>"
        f"{paths}</svg></span>"
    )


BEST_BADGE = _badge(
    "<path d='M8 21h8'/><path d='M12 17v4'/><path d='M7 4h10v5a5 5 0 0 1-10 0z'/>"
    "<path d='M17 5h3v2a3 3 0 0 1-3 3'/><path d='M7 5H4v2a3 3 0 0 0 3 3'/>")
DICE_BADGE = _badge(
    "<rect x='4' y='4' width='16' height='16' rx='3'/>"
    "<circle cx='9' cy='9' r='1' fill='#fff'/><circle cx='15' cy='15' r='1' fill='#fff'/>"
    "<circle cx='12' cy='12' r='1' fill='#fff'/>")


def metric_cards_html(metrics):
    """
    metrics: list of (label, value_str) tuples.
    Renders a responsive grid of clean metric cards.
    """
    cards = "".join(
        f"""
        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px;
                    padding:14px 16px; min-width:130px;">
            <div style="font-size:12px; color:#64748b; font-weight:bold; text-transform:uppercase;
                        letter-spacing:0.03em; margin-bottom:6px;">{label}</div>
            <div style="font-size:20px; color:#1e293b; font-weight:bold;">{value}</div>
        </div>
        """
        for label, value in metrics
    )
    return (
        "<div style='display:flex; flex-wrap:wrap; gap:12px; margin:14px 0;'>"
        f"{cards}"
        "</div>"
    )



# Regression
# ---------------------------------------------------------

MODEL_LABELS = {
    "linear": "Linear Regression",
    "random_forest": "Random Forest",
    "decision_tree": "Decision Tree",
    "flaml": "AutoML (FLAML)",
}


GRADIENT_MODEL_LABELS = {
    "xgboost": "XGBoost",
    "catboost": "CatBoost",
    "adaboost": "AdaBoost",
    "lightgbm": "LightGBM",
}


def build_model(model_type):
    if model_type == "linear":
        return LinearRegression()
    if model_type == "random_forest":
        return RandomForestRegressor(n_estimators=100, random_state=42)
    if model_type == "decision_tree":
        return DecisionTreeRegressor(random_state=42)
    if model_type == "flaml":
        if not FLAML_AVAILABLE:
            raise ValueError(
                "FLAML is not installed on the server. Run: pip install \"flaml[automl]\""
            )
        return AutoML()
    raise ValueError(f"Unknown model type: {model_type}")


def build_gradient_model(model_type):
    if model_type == "xgboost":
        if not XGBOOST_AVAILABLE:
            raise ValueError("XGBoost is not installed. Run: pip install xgboost")
        return XGBRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=4,
            subsample=0.9, colsample_bytree=0.9, objective="reg:squarederror",
            random_state=42, n_jobs=-1
        )
    if model_type == "catboost":
        if not CATBOOST_AVAILABLE:
            raise ValueError("CatBoost is not installed. Run: pip install catboost")
        return CatBoostRegressor(
            iterations=200, learning_rate=0.05, depth=6,
            loss_function="RMSE", verbose=False, random_seed=42
        )
    if model_type == "adaboost":
        return AdaBoostRegressor(n_estimators=200, learning_rate=0.05, random_state=42)
    if model_type == "lightgbm":
        if not LIGHTGBM_AVAILABLE:
            raise ValueError("LightGBM is not installed. Run: pip install lightgbm")
        # Default min_child_samples/num_leaves assume larger datasets; on small
        # CSVs (a few dozen rows or fewer) they cause LightGBM to underfit to a
        # near-constant prediction, so they're relaxed here.
        return LGBMRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=-1,
            min_child_samples=1, num_leaves=7, min_split_gain=0.0,
            random_state=42, verbosity=-1
        )
    raise ValueError(f"Unknown gradient model type: {model_type}")


def run_regression_core(csv_data, independent, dependent, model_type="linear"):
    """Shared logic for both the JSON endpoint and the PDF endpoint."""

    if model_type not in MODEL_LABELS:
        raise ValueError(f"Unknown model type: {model_type}")

    df = read_csv_df(csv_data)

    for column in independent:
        if column not in df.columns:
            raise ValueError(f"Independent variable '{column}' not found in CSV.")

    if dependent not in df.columns:
        raise ValueError(f"Dependent variable '{dependent}' not found in CSV.")

    # Converts text/category columns to numeric features via TF-IDF automatically;
    # numeric columns pass through unchanged. feature_columns may differ from
    # `independent` if any text column expanded into multiple TF-IDF columns.
    X, feature_columns, text_columns_vectorized = build_feature_matrix(df, independent)
    Y = pd.to_numeric(df[dependent], errors="coerce")

    data_clean = pd.concat([X, Y], axis=1).dropna()
    if len(data_clean) == 0:
        raise ValueError("No valid numeric rows left after cleaning. Check your data.")

    X = data_clean[feature_columns]
    Y = data_clean[dependent]

    # Train/test split so models can be fairly compared on unseen data.
    # Falls back to using all rows for both train and test on very small datasets.
    split_note = None
    if len(data_clean) >= 5:
        X_train, X_test, Y_train, Y_test = train_test_split(
            X, Y, test_size=0.2, random_state=42
        )
    else:
        X_train, X_test, Y_train, Y_test = X, X, Y, Y
        split_note = "Dataset too small to split — evaluated on the same data used for training."

    model = build_model(model_type)

    best_config = None
    best_estimator_name = None

    if model_type == "flaml":
        model.fit(
            X_train=X_train.to_numpy(),
            y_train=Y_train.to_numpy(),
            task="regression",
            time_budget=15,
            verbose=0,
        )
        predictions = model.predict(X_test.to_numpy())
        best_config = model.best_config
        best_estimator_name = model.best_estimator
    else:
        model.fit(X_train, Y_train)
        predictions = model.predict(X_test)

    predictions = np.asarray(predictions)

    r_squared = float(r2_score(Y_test, predictions)) if len(Y_test) > 1 else float("nan")
    mae = mean_absolute_error(Y_test, predictions)
    mse = mean_squared_error(Y_test, predictions)

    # Coefficients (linear) or feature importances (tree-based) if available.
    # Keyed by the final numeric feature names (post TF-IDF expansion).
    coefficients = None
    intercept = None
    feature_importances = None

    if model_type == "linear":
        intercept = float(model.intercept_)
        coefficients = dict(zip(feature_columns, model.coef_))
    elif model_type in ("random_forest", "decision_tree"):
        feature_importances = dict(zip(feature_columns, model.feature_importances_))

    return {
        "model_type": model_type,
        "model_label": MODEL_LABELS[model_type],
        "best_estimator_name": best_estimator_name,
        "best_config": best_config,
        "r_squared": r_squared,
        "mae": mae,
        "mse": mse,
        "rmse": float(np.sqrt(mse)),
        "actual": Y_test.reset_index(drop=True) if hasattr(Y_test, "reset_index") else pd.Series(Y_test).reset_index(drop=True),
        "predicted": predictions,
        "intercept": intercept,
        "coefficients": coefficients,
        "feature_importances": feature_importances,
        "split_note": split_note,
        "feature_columns": feature_columns,
        "text_columns_vectorized": text_columns_vectorized,
    }


@app.route("/regression", methods=["POST"])
def regression():
    try:
        data = request.get_json()

        csv_data = data.get("csv")
        independent = data.get("independent")
        dependent = data.get("dependent")
        model_type = data.get("model", "linear")

        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400
        if not independent:
            return jsonify({"message": "Paste independent variable."}), 400
        if not dependent:
            return jsonify({"message": "Paste dependent variable."}), 400

        result = run_regression_core(csv_data, independent, dependent, model_type)

        actual = result["actual"]
        predicted = result["predicted"]

        preview_rows = min(10, len(actual))
        table_html = "<table style='width:100%; border-collapse:collapse; margin-top:8px;'>"
        table_html += (
            "<tr><th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>Actual</th>"
            "<th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>Predicted</th></tr>"
        )
        for i in range(preview_rows):
            table_html += (
                f"<tr><td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{actual.iloc[i]:.4f}</td>"
                f"<td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{predicted[i]:.4f}</td></tr>"
            )
        table_html += "</table>"

        if len(actual) > preview_rows:
            table_html += (
                f"<p style='margin-top:6px; font-size:12px; color:#64748b;'>"
                f"Showing {preview_rows} of {len(actual)} test rows. Download the PDF for the full table.</p>"
            )

        result_msg = f"{result['model_label']} Completed Successfully<br><br>"
        result_msg += f"<b>Dependent Variable:</b> {dependent}<br>"
        result_msg += f"<b>Independent Variable(s):</b> {', '.join(independent)}<br>"

        if result["text_columns_vectorized"]:
            result_msg += (
                f"<i style='color:#0369a1;'>Text column(s) converted to numeric features via TF-IDF: "
                f"{', '.join(result['text_columns_vectorized'])}</i><br>"
            )

        if result["split_note"]:
            result_msg += f"<i style='color:#b45309;'>{result['split_note']}</i><br>"

        # --- Metric cards ---
        metrics = [
            ("R² Score", f"{result['r_squared']:.4f}" if result['r_squared'] == result['r_squared'] else "N/A"),
            ("MAE", f"{result['mae']:.4f}"),
            ("MSE", f"{result['mse']:.4f}"),
            ("RMSE", f"{result['rmse']:.4f}"),
        ]
        if result["model_type"] == "linear":
            metrics.append(("Intercept", f"{result['intercept']:.4f}"))
        result_msg += metric_cards_html(metrics)

        if result["model_type"] == "linear":
            result_msg += "<b>Coefficients:</b><br>"
            for column, coefficient in result["coefficients"].items():
                result_msg += f"{column}: {coefficient:.4f}<br>"
            result_msg += "<br>"

        elif result["model_type"] in ("random_forest", "decision_tree"):
            result_msg += "<b>Feature Importances:</b><br>"
            for column, importance in result["feature_importances"].items():
                result_msg += f"{column}: {importance:.4f}<br>"
            result_msg += "<br>"

        elif result["model_type"] == "flaml":
            result_msg += f"<b>Best Model Found:</b> {result['best_estimator_name']}<br>"
            result_msg += f"<b>Best Config:</b> {result['best_config']}<br><br>"

        result_msg += "<b>Actual vs Predicted (test set):</b>"
        result_msg += table_html

        chart = chart_actual_vs_predicted(
            actual.to_numpy(), predicted,
            title=f"{result['model_label']} — Actual vs Predicted"
        )

        scatter_line = chart_regression_scatter_line(read_csv_df(csv_data), independent, dependent)
        charts = [{"id": "regression-avp-chart", "figure": chart}]
        if scatter_line:
            charts.insert(0, {"id": "regression-scatter-line-chart", "figure": scatter_line})

        return jsonify({
            "message": result_msg,
            "charts": charts,
        })

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Regression Error", e)
        return jsonify({"message": f"Regression Error: {str(e)}"}), 500


@app.route("/regression/report", methods=["POST"])
def regression_report():
    try:
        data = request.get_json()

        csv_data = data.get("csv")
        independent = data.get("independent")
        dependent = data.get("dependent")
        model_type = data.get("model", "linear")

        if not csv_data or not independent or not dependent:
            return jsonify({"message": "Missing CSV or column names."}), 400

        result = run_regression_core(csv_data, independent, dependent, model_type)
        actual = result["actual"]
        predicted = result["predicted"]

        meta_lines = [
            f"<b>Model:</b> {result['model_label']}",
            f"<b>Dependent Variable:</b> {dependent}",
            f"<b>Independent Variable(s):</b> {', '.join(independent)}",
        ]

        if result["text_columns_vectorized"]:
            meta_lines.append(
                f"<i>Text column(s) converted via TF-IDF: {', '.join(result['text_columns_vectorized'])}</i>"
            )

        if result["split_note"]:
            meta_lines.append(f"<i>{result['split_note']}</i>")

        if result["model_type"] == "linear":
            meta_lines.append(f"<b>Intercept:</b> {result['intercept']:.4f}")
            for column, coefficient in result["coefficients"].items():
                meta_lines.append(f"<b>Coefficient ({column}):</b> {coefficient:.4f}")

        elif result["model_type"] in ("random_forest", "decision_tree"):
            for column, importance in result["feature_importances"].items():
                meta_lines.append(f"<b>Feature Importance ({column}):</b> {importance:.4f}")

        elif result["model_type"] == "flaml":
            meta_lines.append(f"<b>Best Model Found:</b> {result['best_estimator_name']}")
            meta_lines.append(f"<b>Best Config:</b> {result['best_config']}")

        r2_display = f"{result['r_squared']:.4f}" if result["r_squared"] == result["r_squared"] else "N/A"
        meta_lines.append(f"<b>R2 Score (test set):</b> {r2_display}")
        meta_lines.append(f"<b>Mean Absolute Error (MAE):</b> {result['mae']:.4f}")
        meta_lines.append(f"<b>Mean Squared Error (MSE):</b> {result['mse']:.4f}")
        meta_lines.append(f"<b>Root Mean Squared Error (RMSE):</b> {result['rmse']:.4f}")

        max_rows = 50
        row_count = min(max_rows, len(actual))
        table_rows = [
            [f"{actual.iloc[i]:.4f}", f"{predicted[i]:.4f}"]
            for i in range(row_count)
        ]

        note = None
        if len(actual) > max_rows:
            note = f"Showing {max_rows} of {len(actual)} test rows."

        chart_images = [
            (f"{result['model_label']} — Actual vs Predicted",
             pdf_scatter(np.asarray(actual), np.asarray(predicted),
                         f"{result['model_label']} — Actual vs Predicted"))
        ]
        line_chart = pdf_regression_line(read_csv_df(csv_data), independent, dependent)
        if line_chart:
            chart_images.insert(0, (f"Regression — {dependent} vs {independent[0]}", line_chart))

        pdf_buffer = build_pdf(
            title=f"{result['model_label']} Report",
            meta_lines=meta_lines,
            table_headers=["Actual", "Predicted"],
            table_rows=table_rows,
            chart_images=chart_images,
            note=note,
        )

        return send_file(
            pdf_buffer,
            mimetype="application/pdf",
            as_attachment=True,
            download_name="regression_report.pdf",
        )

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Regression Report Error", e)
        return jsonify({"message": f"Regression Report Error: {str(e)}"}), 500


# ---------------------------------------------------------
# Multi Models (compare all models side by side)
# ---------------------------------------------------------

def run_multimodel_core(csv_data, independent, dependent):
    """
    Runs every available model on the same data and returns a comparison.
    A model that fails (e.g. FLAML not installed) is skipped with its error
    recorded, rather than failing the whole comparison.
    """

    results = []
    errors = []

    for model_type in MODEL_LABELS:
        try:
            r = run_regression_core(csv_data, independent, dependent, model_type)
            results.append(r)
        except Exception as e:
            errors.append({"model_type": model_type, "model_label": MODEL_LABELS[model_type], "error": str(e)})

    if not results:
        raise ValueError("None of the models could be run. " + "; ".join(e["error"] for e in errors))

    # Rank by R2 score (higher is better)
    results_sorted = sorted(results, key=lambda r: (r["r_squared"] if r["r_squared"] == r["r_squared"] else -1), reverse=True)

    return results_sorted, errors


@app.route("/multimodel", methods=["POST"])
def multimodel():
    try:
        data = request.get_json()

        csv_data = data.get("csv")
        independent = data.get("independent")
        dependent = data.get("dependent")

        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400
        if not independent:
            return jsonify({"message": "Paste independent variable."}), 400
        if not dependent:
            return jsonify({"message": "Paste dependent variable."}), 400

        results_sorted, errors = run_multimodel_core(csv_data, independent, dependent)

        best = results_sorted[0]

        result_msg = "Multi Model Comparison Completed Successfully<br><br>"
        result_msg += f"<b>Dependent Variable:</b> {dependent}<br>"
        result_msg += f"<b>Independent Variable(s):</b> {', '.join(independent)}<br><br>"

        result_msg += "<table style='width:100%; border-collapse:collapse; margin-top:8px;'>"
        result_msg += (
            "<tr>"
            "<th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>Model</th>"
            "<th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>R2 Score</th>"
            "<th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>MAE</th>"
            "<th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>MSE</th>"
            "</tr>"
        )
        for r in results_sorted:
            is_best = (r is best)
            row_style = "background:#dcfce7; font-weight:bold;" if is_best else ""
            label = r["model_label"] + (BEST_BADGE if is_best else "")
            r2_display = f"{r['r_squared']:.4f}" if r["r_squared"] == r["r_squared"] else "N/A"
            result_msg += (
                f"<tr style='{row_style}'>"
                f"<td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{label}</td>"
                f"<td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{r2_display}</td>"
                f"<td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{r['mae']:.4f}</td>"
                f"<td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{r['mse']:.4f}</td>"
                "</tr>"
            )
        result_msg += "</table>"

        if errors:
            result_msg += "<br><b>Skipped:</b><br>"
            for e in errors:
                result_msg += f"{e['model_label']}: {e['error']}<br>"

        result_msg += f"<br><b>Best Model:</b> {best['model_label']} (highest R2 on test set)"

        chart = chart_multimodel_scatter(results_sorted)

        return jsonify({
            "message": result_msg,
            "charts": [
                {"id": "multimodel-scatter-chart", "figure": chart},
                {"id": "multimodel-score-chart", "figure": chart_model_comparison(results_sorted)},
            ],
        })

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Multi Model Error", e)
        return jsonify({"message": f"Multi Model Error: {str(e)}"}), 500


@app.route("/multimodel/report", methods=["POST"])
def multimodel_report():
    try:
        data = request.get_json()

        csv_data = data.get("csv")
        independent = data.get("independent")
        dependent = data.get("dependent")

        if not csv_data or not independent or not dependent:
            return jsonify({"message": "Missing CSV or column names."}), 400

        results_sorted, errors = run_multimodel_core(csv_data, independent, dependent)
        best = results_sorted[0]

        meta_lines = [
            f"<b>Dependent Variable:</b> {dependent}",
            f"<b>Independent Variable(s):</b> {', '.join(independent)}",
            f"<b>Best Model:</b> {best['model_label']} (highest R2 on test set)",
        ]

        if errors:
            for e in errors:
                meta_lines.append(f"<i>Skipped {e['model_label']}: {e['error']}</i>")

        table_rows = []
        for r in results_sorted:
            r2_display = f"{r['r_squared']:.4f}" if r["r_squared"] == r["r_squared"] else "N/A"
            label = r["model_label"] + (" (Best)" if r is best else "")
            table_rows.append([label, r2_display, f"{r['mae']:.4f}", f"{r['mse']:.4f}"])

        chart_images = []
        for r in results_sorted:
            chart_images.append((
                f"{r['model_label']} — Actual vs Predicted",
                pdf_scatter(np.asarray(r["actual"]), np.asarray(r["predicted"]),
                            f"{r['model_label']} — Actual vs Predicted")
            ))

        pdf_buffer = build_pdf(
            title="Multi Model Comparison Report",
            meta_lines=meta_lines,
            table_headers=["Model", "R2 Score", "MAE", "MSE"],
            table_rows=table_rows,
            chart_images=chart_images,
        )

        return send_file(
            pdf_buffer,
            mimetype="application/pdf",
            as_attachment=True,
            download_name="multimodel_report.pdf",
        )

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Multi Model Report Error", e)
        return jsonify({"message": f"Multi Model Report Error: {str(e)}"}), 500


# ---------------------------------------------------------
# Simulation
# ---------------------------------------------------------

def run_simulation_core(csv_data):
    df = read_csv_df(csv_data)
    col = first_numeric_column(df)

    if col is None:
        raise ValueError("No numeric column found in the CSV.")

    values = pd.to_numeric(df[col], errors="coerce").dropna()
    if len(values) == 0:
        raise ValueError("No valid numeric values found after cleaning.")

    values_np = values.to_numpy()
    n = len(values_np)

    # --- Monte Carlo Simulation (trend-based) ---
    # Treats the CSV rows as a sequence (index 1..n) and fits a straight-line
    # trend through the data (least squares). The "next value" is predicted
    # by extrapolating that trend one step forward, then Monte Carlo is used
    # to simulate the *uncertainty* around that prediction: thousands of
    # trials add randomly resampled historical residuals (the noise left
    # over after removing the trend) to the trend forecast. This lets the
    # model actually extrapolate beyond the observed range (e.g. 1,2,3,4,5
    # correctly predicts ~6) while still reflecting how noisy the data is.
    x = np.arange(1, n + 1, dtype=float)

    if n >= 2:
        slope, intercept = np.polyfit(x, values_np, 1)
        if abs(slope) < 1e-9:
            slope = 0.0
    else:
        # Can't fit a trend line with a single point — treat it as flat.
        slope, intercept = 0.0, float(values_np[0])

    fitted = slope * x + intercept
    residuals = values_np - fitted

    next_index = n + 1
    trend_forecast = slope * next_index + intercept

    rng = np.random.default_rng(42)
    num_simulations = 10000

    if n >= 2 and np.std(residuals) > 1e-9:
        # Bootstrap historical residuals. Keep the selected residual index so
        # the dashboard can show how often each original observation was used.
        selected_indices = rng.integers(0, len(residuals), size=num_simulations)
        simulated_noise = residuals[selected_indices]
        simulated = trend_forecast + simulated_noise
    else:
        selected_indices = np.zeros(num_simulations, dtype=int)
        simulated = np.full(num_simulations, trend_forecast)

    # Multi-step Monte Carlo paths for formal path visualization.
    path_steps = min(40, max(5, n))
    path_indices = rng.integers(0, max(1, len(residuals)), size=(100, path_steps))
    path_noise = residuals[path_indices]
    future_x = np.arange(n + 1, n + 1 + path_steps, dtype=float)
    future_trend = slope * future_x + intercept
    simulated_paths = future_trend[None, :] + path_noise

    predicted_next = float(np.mean(simulated))
    ci_lower = float(np.percentile(simulated, 5))
    ci_upper = float(np.percentile(simulated, 95))

    return {
        "column": col,
        "count": n,
        "mean": float(np.mean(values_np)),
        "std": float(np.std(values_np)),
        "p25": float(np.percentile(values_np, 25)),
        "p50": float(np.percentile(values_np, 50)),
        "p75": float(np.percentile(values_np, 75)),
        "num_simulations": num_simulations,
        "trend_slope": float(slope),
        "predicted_next": predicted_next,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "simulated": simulated,
        "selected_indices": selected_indices,
        "simulated_paths": simulated_paths,
    }


@app.route("/simulation", methods=["POST"])
def simulation():
    try:
        data = request.get_json()
        csv_data = data.get("csv")

        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400

        r = run_simulation_core(csv_data)

        result_msg = "Simulation Completed Successfully<br><br>"
        result_msg += f"<b>Column Used:</b> {r['column']}<br>"
        result_msg += f"<b>Sample Size:</b> {r['count']}<br>"

        metrics = [
            ("Mean", f"{r['mean']:.4f}"),
            ("Std Dev", f"{r['std']:.4f}"),
            ("25th %ile", f"{r['p25']:.4f}"),
            ("Median", f"{r['p50']:.4f}"),
            ("75th %ile", f"{r['p75']:.4f}"),
        ]
        result_msg += metric_cards_html(metrics)

        result_msg += (
            "<div style='margin-top:6px; padding:18px; background:#dcfce7; "
            "border:2px solid #16a34a; border-radius:10px;'>"
            "<div style='color:#065f46; font-weight:bold; font-size:14px; margin-bottom:8px;'>"
            f"{DICE_BADGE}Monte Carlo Prediction ({r['num_simulations']:,} simulated trials)"
            "</div>"
            "<div style='color:#065f46; font-weight:bold; font-size:20px;'>"
            f"Predicted Next Value: {r['predicted_next']:.4f}"
            "</div>"
            "<div style='color:#065f46; font-size:14px; margin-top:6px;'>"
            f"90% Confidence Range: {r['ci_lower']:.4f} &ndash; {r['ci_upper']:.4f}"
            "</div>"
            "<div style='color:#065f46; font-size:12px; margin-top:6px; opacity:0.85;'>"
            f"Trend: {'+' if r['trend_slope'] >= 0 else ''}{r['trend_slope']:.4f} per step"
            "</div>"
            "</div>"
        )

        values_np = pd.to_numeric(read_csv_df(csv_data)[r["column"]], errors="coerce").dropna().to_numpy()
        histogram_chart = chart_simulation_histogram(r["simulated"], r["predicted_next"])
        frequency_chart = chart_simulation_frequency(values_np, r["selected_indices"])
        path_chart = chart_monte_carlo_paths(r["simulated_paths"])
        convergence_chart = chart_simulation_convergence(r["simulated"])

        return jsonify({
            "message": result_msg,
            "charts": [
                {"id": "simulation-histogram-chart", "figure": histogram_chart},
                {"id": "simulation-frequency-chart", "figure": frequency_chart},
                {"id": "simulation-path-chart", "figure": path_chart},
                {"id": "simulation-convergence-chart", "figure": convergence_chart},
            ],
        })

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Simulation Error", e)
        return jsonify({"message": f"Simulation Error: {str(e)}"}), 500


@app.route("/simulation/report", methods=["POST"])
def simulation_report():
    try:
        data = request.get_json()
        csv_data = data.get("csv")

        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400

        r = run_simulation_core(csv_data)

        meta_lines = [
            f"<b>Column Used:</b> {r['column']}",
            f"<b>Sample Size:</b> {r['count']}",
            f"<b>Mean:</b> {r['mean']:.4f}",
            f"<b>Standard Deviation:</b> {r['std']:.4f}",
            f"<b>25th Percentile:</b> {r['p25']:.4f}",
            f"<b>50th Percentile (Median):</b> {r['p50']:.4f}",
            f"<b>75th Percentile:</b> {r['p75']:.4f}",
        ]

        values_np = pd.to_numeric(read_csv_df(csv_data)[r["column"]], errors="coerce").dropna().to_numpy()
        chart_images = [
            ("Monte Carlo — Outcome Distribution", _pdf_sim_hist(r["simulated"], r["predicted_next"])),
            ("Monte Carlo — Sample Usage Frequency", _pdf_sim_frequency(values_np, r["selected_indices"])),
            ("Monte Carlo — Simulation Paths", _pdf_sim_paths(r["simulated_paths"])),
        ]

        pdf_buffer = build_pdf(
            title="Simulation Report",
            meta_lines=meta_lines,
            highlight_title=f"Monte Carlo Prediction ({r['num_simulations']:,} simulated trials)",
            highlight_lines=[
                f"Predicted Next Value: {r['predicted_next']:.4f}",
                f"90% Confidence Range: {r['ci_lower']:.4f} to {r['ci_upper']:.4f}",
                f"Trend: {'+' if r['trend_slope'] >= 0 else ''}{r['trend_slope']:.4f} per step",
            ],
            chart_images=chart_images,
        )

        return send_file(
            pdf_buffer,
            mimetype="application/pdf",
            as_attachment=True,
            download_name="simulation_report.pdf",
        )

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Simulation Report Error", e)
        return jsonify({"message": f"Simulation Report Error: {str(e)}"}), 500


# ---------------------------------------------------------
# Gradient
# ---------------------------------------------------------


def run_gradient_core(csv_data, independent, dependent):
    """
    Automatically trains XGBoost, CatBoost, AdaBoost and LightGBM on the
    user's selected data. The model with the highest test-set R² (and lowest
    MSE as a tie-breaker) is selected as the best gradient boosting model.
    """
    df = read_csv_df(csv_data)

    for column in independent:
        if column not in df.columns:
            raise ValueError(f"Independent variable '{column}' not found in CSV.")
    if dependent not in df.columns:
        raise ValueError(f"Dependent variable '{dependent}' not found in CSV.")

    X, feature_columns, text_columns_vectorized = build_feature_matrix(df, independent)
    Y = pd.to_numeric(df[dependent], errors="coerce")
    data_clean = pd.concat([X, Y], axis=1).dropna()

    if len(data_clean) < 2:
        raise ValueError("At least 2 valid rows are required for gradient model selection.")

    X = data_clean[feature_columns].to_numpy(dtype=float)
    Y = data_clean[dependent].to_numpy(dtype=float)

    if len(data_clean) >= 5:
        X_train, X_test, y_train, y_test = train_test_split(
            X, Y, test_size=0.2, random_state=42
        )
        split_note = None
    else:
        X_train, X_test, y_train, y_test = X, X, Y, Y
        split_note = "Dataset too small for a train/test split; results are training-set evaluation."

    results = []
    errors = []

    for model_type, model_label in GRADIENT_MODEL_LABELS.items():
        try:
            model = build_gradient_model(model_type)
            if model_type == "xgboost":
                model.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)
            elif model_type == "catboost":
                model.fit(X_train, y_train, eval_set=(X_test, y_test), verbose=False)
            elif model_type == "lightgbm":
                model.fit(X_train, y_train, eval_X=X_test, eval_y=y_test, eval_metric="l2")
            else:
                model.fit(X_train, y_train)

            predictions = np.asarray(model.predict(X_test), dtype=float)
            mse = float(mean_squared_error(y_test, predictions))
            mae = float(mean_absolute_error(y_test, predictions))
            r2 = float(r2_score(y_test, predictions)) if len(y_test) > 1 else float("nan")

            # Cost history: where the library exposes staged predictions, use
            # the validation MSE at each boosting iteration. Otherwise the
            # final MSE is still a valid cost-function point.
            cost_history = [mse]
            try:
                if model_type == "adaboost":
                    cost_history = [
                        float(mean_squared_error(y_test, pred))
                        for pred in model.staged_predict(X_test)
                    ]
                elif model_type == "xgboost":
                    evals_result = model.evals_result()
                    vals = evals_result.get("validation_0", {}).get("rmse", [])
                    if vals:
                        cost_history = [float(v) ** 2 for v in vals]
                elif model_type == "catboost":
                    evals_result = model.get_evals_result()
                    vals = evals_result.get("validation", evals_result.get("validation_0", {})).get("RMSE", [])
                    if vals:
                        cost_history = [float(v) ** 2 for v in vals]
                elif model_type == "lightgbm":
                    if hasattr(model, "evals_result_"):
                        vals = model.evals_result_.get("valid_0", {}).get("l2", [])
                        if vals:
                            cost_history = [float(v) for v in vals]
            except Exception:
                pass

            results.append({
                "model_type": model_type,
                "model_label": model_label,
                "model": model,
                "r_squared": r2,
                "mae": mae,
                "mse": mse,
                "rmse": float(np.sqrt(mse)),
                "actual": y_test,
                "predicted": predictions,
                "cost_history": cost_history,
            })
        except Exception as e:
            errors.append({"model_label": model_label, "error": str(e)})

    if not results:
        raise ValueError("None of the gradient boosting models could be run.")

    results.sort(key=lambda r: (
        r["r_squared"] if np.isfinite(r["r_squared"]) else -np.inf,
        -r["mse"]
    ), reverse=True)

    return {
        "results": results,
        "best": results[0],
        "errors": errors,
        "feature_columns": feature_columns,
        "text_columns_vectorized": text_columns_vectorized,
        "split_note": split_note,
    }


@app.route("/gradient", methods=["POST"])
def gradient():
    try:
        data = request.get_json()
        csv_data = data.get("csv")
        independent = data.get("independent")
        dependent = data.get("dependent")

        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400
        if not independent:
            return jsonify({"message": "Please provide independent variable(s)."}), 400
        if not dependent:
            return jsonify({"message": "Please provide a dependent variable."}), 400

        result = run_gradient_core(csv_data, independent, dependent)
        best = result["best"]

        result_msg = "Automatic Gradient Boosting Model Selection Completed Successfully<br><br>"
        result_msg += f"<b>Dependent Variable:</b> {dependent}<br>"
        result_msg += f"<b>Independent Variable(s):</b> {', '.join(independent)}<br>"

        if result["text_columns_vectorized"]:
            result_msg += (
                f"<i style='color:#0369a1;'>Text column(s) converted to numeric features via TF-IDF: "
                f"{', '.join(result['text_columns_vectorized'])}</i><br>"
            )
        if result["split_note"]:
            result_msg += f"<i style='color:#b45309;'>{result['split_note']}</i><br>"

        result_msg += "<br><b>Model Evaluation</b>"
        result_msg += "<table style='width:100%; border-collapse:collapse; margin-top:8px;'>"
        result_msg += (
            "<tr><th style='text-align:left;border-bottom:2px solid #1e293b;padding:7px;'>Model</th>"
            "<th style='text-align:left;border-bottom:2px solid #1e293b;padding:7px;'>R²</th>"
            "<th style='text-align:left;border-bottom:2px solid #1e293b;padding:7px;'>MAE</th>"
            "<th style='text-align:left;border-bottom:2px solid #1e293b;padding:7px;'>MSE Cost</th></tr>"
        )
        for row in result["results"]:
            best_style = "background:#dcfce7;font-weight:bold;" if row is best else ""
            r2_display = f"{row['r_squared']:.4f}" if row["r_squared"] == row["r_squared"] else "N/A"
            result_msg += (
                f"<tr style='{best_style}'><td style='padding:7px;'>{row['model_label']}"
                f"{(BEST_BADGE + 'Best Model') if row is best else ''}</td>"
                f"<td style='padding:7px;'>{r2_display}</td>"
                f"<td style='padding:7px;'>{row['mae']:.4f}</td>"
                f"<td style='padding:7px;'>{row['mse']:.4f}</td></tr>"
            )
        result_msg += "</table>"

        best_r2_display = f"{best['r_squared']:.4f}" if best["r_squared"] == best["r_squared"] else "N/A"
        result_msg += (
            f"<div style='margin-top:16px;padding:16px;background:#eff6ff;border:1px solid #2563eb;"
            f"border-radius:10px;'><b>Selected Best Gradient Model:</b> {best['model_label']}<br>"
            f"Highest test-set R² = {best_r2_display}; MSE Cost = {best['mse']:.4f}</div>"
        )

        charts = [
            {"id": "gradient-cost-chart", "figure": chart_gradient_cost_function(result["results"])},
            {"id": "gradient-convergence-chart",
             "figure": chart_gradient_convergence(best["cost_history"], best["model_label"])},
            {"id": "gradient-best-prediction-chart",
             "figure": chart_actual_vs_predicted(best["actual"], best["predicted"],
                                                  f"{best['model_label']} — Actual vs Predicted")},
        ]

        return jsonify({"message": result_msg, "charts": charts})

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Gradient Error:", e)
        return jsonify({"message": f"Gradient Error: {str(e)}"}), 500


@app.route("/gradient/report", methods=["POST"])
def gradient_report():
    try:
        data = request.get_json()
        csv_data = data.get("csv")
        independent = data.get("independent")
        dependent = data.get("dependent")
        if not csv_data or not independent or not dependent:
            return jsonify({"message": "Missing CSV or column names."}), 400

        result = run_gradient_core(csv_data, independent, dependent)
        best = result["best"]

        best_r2_display = f"{best['r_squared']:.4f}" if best["r_squared"] == best["r_squared"] else "N/A"
        meta_lines = [
            "<b>Method:</b> Automatic Gradient Boosting Model Selection",
            f"<b>Dependent Variable:</b> {dependent}",
            f"<b>Independent Variable(s):</b> {', '.join(independent)}",
            f"<b>Selected Best Model:</b> {best['model_label']}",
            f"<b>Best R²:</b> {best_r2_display}",
            f"<b>Best MAE:</b> {best['mae']:.4f}",
            f"<b>Best MSE Cost:</b> {best['mse']:.4f}",
        ]
        if result["text_columns_vectorized"]:
            meta_lines.append(f"<i>TF-IDF text columns: {', '.join(result['text_columns_vectorized'])}</i>")
        if result["split_note"]:
            meta_lines.append(f"<i>{result['split_note']}</i>")

        table_rows = [
            [r["model_label"],
             f"{r['r_squared']:.4f}" if r["r_squared"] == r["r_squared"] else "N/A",
             f"{r['mae']:.4f}", f"{r['mse']:.4f}", f"{r['rmse']:.4f}"]
            for r in result["results"]
        ]

        charts = [
            ("Cost Function — MSE by Model", pdf_cost_chart(result["results"])),
            (f"{best['model_label']} — Cost Function Across Boosting Iterations",
             pdf_cost_history(best["cost_history"], best["model_label"])),
            (f"{best['model_label']} — Actual vs Predicted",
             pdf_scatter(np.asarray(best["actual"]), np.asarray(best["predicted"]),
                         f"{best['model_label']} — Actual vs Predicted")),
        ]

        pdf_buffer = build_pdf(
            title="Automatic Gradient Boosting Model Selection Report",
            meta_lines=meta_lines,
            table_headers=["Model", "R²", "MAE", "MSE Cost", "RMSE"],
            table_rows=table_rows,
            chart_images=charts,
            note="The selected model is ranked primarily by test-set R², with MSE used as the tie-breaker.",
        )
        return send_file(pdf_buffer, mimetype="application/pdf",
                         as_attachment=True, download_name="gradient_report.pdf")
    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Gradient Report Error:", e)
        return jsonify({"message": f"Gradient Report Error: {str(e)}"}), 500


# ---------------------------------------------------------
# Hypothesis Testing
# ---------------------------------------------------------

HYPOTHESIS_TEST_INFO = {
    "ttest": "Compares the means of two independent groups to see if they differ significantly.",
    "ztest": "Compares two group means using a z-statistic, best suited to large sample sizes.",
    "chisq": "Tests whether two categorical variables are associated with each other.",
    "anova": "Compares the means of three or more groups at once to see if at least one differs.",
}


@app.route("/hypothesis", methods=["POST"])
def hypothesis():
    try:
        data = request.get_json()

        test = data.get("test")
        csv_data = data.get("csv")

        if not test or test not in HYPOTHESIS_TEST_INFO:
            return jsonify({"message": "Please choose a valid hypothesis test."}), 400

        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400

        df = read_csv_df(csv_data)

        if test in ("ttest", "ztest", "anova"):
            group_col = data.get("group_col")
            value_col = data.get("value_col")

            if not group_col or not value_col:
                return jsonify({"message": "Please provide both the group and value column names."}), 400

            if group_col not in df.columns:
                return jsonify({"message": f"Group column '{group_col}' not found in CSV."}), 400
            if value_col not in df.columns:
                return jsonify({"message": f"Value column '{value_col}' not found in CSV."}), 400

            work = df[[group_col, value_col]].copy()
            work[value_col] = pd.to_numeric(work[value_col], errors="coerce")
            work = work.dropna()
            work[group_col] = work[group_col].astype(str).str.strip()

            groups = work.groupby(group_col)[value_col].apply(list)

            if test in ("ttest", "ztest") and len(groups) != 2:
                return jsonify({
                    "message": f"This test needs exactly 2 groups in '{group_col}', found {len(groups)}."
                }), 400

            if test == "anova" and len(groups) < 2:
                return jsonify({
                    "message": f"ANOVA needs at least 2 groups in '{group_col}', found {len(groups)}."
                }), 400

            if any(len(g) < 2 for g in groups):
                return jsonify({
                    "message": "Each group needs at least 2 numeric values."
                }), 400

            if all(float(np.ptp(np.asarray(g, dtype=float))) == 0 for g in groups) and test != "chisquare":
                return jsonify({
                    "message": "All values are identical, so the test cannot be calculated. Please use data with some variation."
                }), 400

            if test == "ttest":
                g1, g2 = groups.iloc[0], groups.iloc[1]
                statistic, p_value = stats.ttest_ind(g1, g2)
                dof = len(g1) + len(g2) - 2

                result_msg = "T-Test Completed Successfully<br><br>"
                result_msg += f"<b>Groups Compared:</b> {groups.index[0]} vs {groups.index[1]}<br>"
                result_msg += metric_cards_html([
                    ("T-Statistic", f"{statistic:.4f}"),
                    ("P-Value", f"{p_value:.4f}"),
                    ("Degrees of Freedom", f"{dof}"),
                ])
                result_msg += conclusion_text(p_value)

                charts = [
                    {"id": "hyp-distribution-chart", "figure": chart_distribution_with_critical_region(
                        "T-Test", statistic, dof=dof)},
                    {"id": "hyp-groups-boxplot", "figure": chart_group_boxplot(
                        {groups.index[0]: g1, groups.index[1]: g2}, title=f"{value_col} by {group_col}")},
                ]

            elif test == "ztest":
                g1 = np.array(groups.iloc[0])
                g2 = np.array(groups.iloc[1])
                mean1, mean2 = np.mean(g1), np.mean(g2)
                var1, var2 = np.var(g1, ddof=1), np.var(g2, ddof=1)
                n1, n2 = len(g1), len(g2)

                se = np.sqrt(var1 / n1 + var2 / n2)
                z_stat = (mean1 - mean2) / se if se > 0 else 0
                p_value = 2 * (1 - stats.norm.cdf(abs(z_stat)))

                result_msg = "Z-Test Completed Successfully<br><br>"
                result_msg += f"<b>Groups Compared:</b> {groups.index[0]} vs {groups.index[1]}<br>"
                result_msg += metric_cards_html([
                    ("Z-Statistic", f"{z_stat:.4f}"),
                    ("P-Value", f"{p_value:.4f}"),
                ])
                result_msg += conclusion_text(p_value)

                charts = [
                    {"id": "hyp-distribution-chart", "figure": chart_distribution_with_critical_region(
                        "Z-Test", z_stat, dof=None)},
                    {"id": "hyp-groups-boxplot", "figure": chart_group_boxplot(
                        {groups.index[0]: g1.tolist(), groups.index[1]: g2.tolist()}, title=f"{value_col} by {group_col}")},
                ]

            else:  # anova
                sample_arrays = [np.array(v) for v in groups]
                statistic, p_value = stats.f_oneway(*sample_arrays)

                result_msg = "ANOVA Completed Successfully<br><br>"
                result_msg += f"<b>Groups Compared:</b> {', '.join(str(g) for g in groups.index)}<br>"
                result_msg += metric_cards_html([
                    ("F-Statistic", f"{statistic:.4f}"),
                    ("P-Value", f"{p_value:.4f}"),
                    ("Groups", f"{len(groups)}"),
                ])
                result_msg += conclusion_text(p_value)

                charts = [
                    {"id": "hyp-groups-boxplot", "figure": chart_group_boxplot(
                        dict(zip(groups.index, groups.tolist())), title=f"{value_col} by {group_col}")},
                ]

        elif test == "chisq":
            col1 = data.get("col1")
            col2 = data.get("col2")

            if not col1 or not col2:
                return jsonify({"message": "Please provide both categorical column names."}), 400

            if col1 not in df.columns:
                return jsonify({"message": f"Column '{col1}' not found in CSV."}), 400
            if col2 not in df.columns:
                return jsonify({"message": f"Column '{col2}' not found in CSV."}), 400

            contingency = pd.crosstab(df[col1], df[col2])
            statistic, p_value, dof, expected = stats.chi2_contingency(contingency)

            result_msg = "Chi-Square Test Completed Successfully<br><br>"
            result_msg += f"<b>Columns Compared:</b> {col1} vs {col2}<br>"
            result_msg += metric_cards_html([
                ("Chi-Square Statistic", f"{statistic:.4f}"),
                ("P-Value", f"{p_value:.4f}"),
                ("Degrees of Freedom", f"{dof}"),
            ])
            result_msg += conclusion_text(p_value)

            charts = [
                {"id": "hyp-chisq-chart", "figure": chart_chisq_observed_expected(contingency, expected)},
            ]

        return jsonify({"message": result_msg, "charts": charts})

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Hypothesis Error", e)
        return jsonify({"message": f"Hypothesis Error: {str(e)}"}), 500


def conclusion_text(p_value, alpha=0.05):
    if p_value < alpha:
        return (
            f"<b>Conclusion:</b> Since p-value ({p_value:.4f}) &lt; {alpha}, "
            f"we reject the null hypothesis — the result is statistically significant."
        )
    return (
        f"<b>Conclusion:</b> Since p-value ({p_value:.4f}) &ge; {alpha}, "
        f"we fail to reject the null hypothesis — the result is not statistically significant."
    )



@app.route("/hypothesis/report", methods=["POST"])
def hypothesis_report():
    """Generate a formal PDF report with the same hypothesis-test visualization shown on screen."""
    try:
        data = request.get_json()
        test = data.get("test")
        csv_data = data.get("csv")
        if test not in HYPOTHESIS_TEST_INFO:
            return jsonify({"message": "Please choose a valid hypothesis test."}), 400
        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400

        df = read_csv_df(csv_data)
        meta_lines = []
        table_headers = None
        table_rows = None
        chart_images = []

        if test in ("ttest", "ztest", "anova"):
            group_col = data.get("group_col")
            value_col = data.get("value_col")
            if not group_col or not value_col:
                return jsonify({"message": "Please provide both the group and value column names."}), 400
            if group_col not in df.columns or value_col not in df.columns:
                return jsonify({"message": "The selected group/value columns were not found in the CSV."}), 400

            work = df[[group_col, value_col]].copy()
            work[value_col] = pd.to_numeric(work[value_col], errors="coerce")
            work = work.dropna()
            work[group_col] = work[group_col].astype(str).str.strip()
            groups = work.groupby(group_col)[value_col].apply(list)

            if test in ("ttest", "ztest") and len(groups) != 2:
                return jsonify({"message": "T-Test and Z-Test require exactly 2 groups."}), 400
            if test == "anova" and len(groups) < 2:
                return jsonify({"message": "ANOVA requires at least 2 groups."}), 400
            if any(len(g) < 2 for g in groups):
                return jsonify({"message": "Each group needs at least 2 numeric values."}), 400
            if all(float(np.ptp(np.asarray(g, dtype=float))) == 0 for g in groups):
                return jsonify({"message": "All values are identical, so the test cannot be calculated. Please use data with some variation."}), 400

            meta_lines.extend([
                f"<b>Test:</b> {HYPOTHESIS_TEST_INFO[test]}",
                f"<b>Group Column:</b> {group_col}",
                f"<b>Value Column:</b> {value_col}",
                "<b>Significance Level:</b> 0.05",
            ])

            if test == "ttest":
                g1, g2 = groups.iloc[0], groups.iloc[1]
                statistic, p_value = stats.ttest_ind(g1, g2)
                dof = len(g1) + len(g2) - 2
                meta_lines += [
                    f"<b>Groups:</b> {groups.index[0]} vs {groups.index[1]}",
                    f"<b>T-Statistic:</b> {statistic:.4f}",
                    f"<b>P-Value:</b> {p_value:.4f}",
                    f"<b>Degrees of Freedom:</b> {dof}",
                    f"<b>Decision:</b> {'Reject H0' if p_value < 0.05 else 'Fail to Reject H0'}",
                ]
                chart_images.append(("T-Test — Distribution and Test Statistic",
                                     pdf_hypothesis_curve("T-Test", statistic, dof=dof)))
                chart_images.append(("T-Test — Group Box Plot",
                                     pdf_boxplot({groups.index[0]: g1, groups.index[1]: g2},
                                                 f"{value_col} by {group_col}")))

            elif test == "ztest":
                g1, g2 = np.asarray(groups.iloc[0]), np.asarray(groups.iloc[1])
                mean1, mean2 = np.mean(g1), np.mean(g2)
                var1, var2 = np.var(g1, ddof=1), np.var(g2, ddof=1)
                se = np.sqrt(var1 / len(g1) + var2 / len(g2))
                z_stat = (mean1 - mean2) / se if se > 0 else 0
                p_value = 2 * (1 - stats.norm.cdf(abs(z_stat)))
                meta_lines += [
                    f"<b>Groups:</b> {groups.index[0]} vs {groups.index[1]}",
                    f"<b>Z-Statistic:</b> {z_stat:.4f}",
                    f"<b>P-Value:</b> {p_value:.4f}",
                    f"<b>Decision:</b> {'Reject H0' if p_value < 0.05 else 'Fail to Reject H0'}",
                ]
                chart_images.append(("Z-Test — Standard Normal Distribution",
                                     pdf_hypothesis_curve("Z-Test", z_stat)))
                chart_images.append(("Z-Test — Group Box Plot",
                                     pdf_boxplot({groups.index[0]: g1, groups.index[1]: g2},
                                                 f"{value_col} by {group_col}")))

            else:
                arrays = [np.asarray(v) for v in groups]
                statistic, p_value = stats.f_oneway(*arrays)
                meta_lines += [
                    f"<b>Groups:</b> {', '.join(str(g) for g in groups.index)}",
                    f"<b>F-Statistic:</b> {statistic:.4f}",
                    f"<b>P-Value:</b> {p_value:.4f}",
                    f"<b>Number of Groups:</b> {len(groups)}",
                    f"<b>Decision:</b> {'Reject H0' if p_value < 0.05 else 'Fail to Reject H0'}",
                ]
                chart_images.append(("ANOVA — Group Distribution (Box Plot)",
                                     pdf_boxplot(dict(zip(groups.index, groups.tolist())),
                                                 f"{value_col} by {group_col}")))

        else:
            col1 = data.get("col1")
            col2 = data.get("col2")
            if not col1 or not col2 or col1 not in df.columns or col2 not in df.columns:
                return jsonify({"message": "Please provide two valid categorical columns."}), 400

            contingency = pd.crosstab(df[col1], df[col2])
            statistic, p_value, dof, expected = stats.chi2_contingency(contingency)
            meta_lines.extend([
                "<b>Test:</b> Chi-Square Test of Independence",
                f"<b>First Categorical Column:</b> {col1}",
                f"<b>Second Categorical Column:</b> {col2}",
                f"<b>Chi-Square Statistic:</b> {statistic:.4f}",
                f"<b>P-Value:</b> {p_value:.4f}",
                f"<b>Degrees of Freedom:</b> {dof}",
                f"<b>Decision:</b> {'Reject H0' if p_value < 0.05 else 'Fail to Reject H0'}",
            ])
            table_headers = ["Category"] + [str(c) for c in contingency.columns]
            table_rows = []
            for idx, row in contingency.iterrows():
                table_rows.append([str(idx)] + [str(int(v)) for v in row.values])
            chart_images.append(("Chi-Square — Observed vs Expected", pdf_chisq(contingency, expected)))

        pdf_buffer = build_pdf(
            title=f"{HYPOTHESIS_TEST_INFO[test].split('.')[0]} Report",
            meta_lines=meta_lines,
            table_headers=table_headers,
            table_rows=table_rows,
            chart_images=chart_images,
            note="Decision rule: reject the null hypothesis when p-value < 0.05.",
        )
        return send_file(pdf_buffer, mimetype="application/pdf",
                         as_attachment=True, download_name="hypothesis_report.pdf")
    except Exception as e:
        print("Hypothesis Report Error:", e)
        return jsonify({"message": f"Hypothesis Report Error: {str(e)}"}), 500


@app.route("/")
def home():
    return render_template("home.html")


# ---------------------------------------------------------
# Neural Network: predict the next numbers from previous values
# ---------------------------------------------------------

NEURAL_DEFAULT_STEPS = 3
NEURAL_MAX_STEPS = 50
NEURAL_MAX_TRAIN_ROWS = 5000


def parse_neural_steps(raw):
    if raw in (None, ""):
        return NEURAL_DEFAULT_STEPS
    try:
        steps = int(float(raw))
    except (TypeError, ValueError):
        raise ValueError("Number of next values must be a whole number.")
    return max(1, min(NEURAL_MAX_STEPS, steps))


def _neural_windows(deltas, lags):
    X = np.array([deltas[t - lags:t] for t in range(lags, len(deltas))])
    y = np.array([deltas[t] for t in range(lags, len(deltas))])
    return X, y


def _fit_neural(X, y):
    """Small neural network (2 hidden layers of 16) on standardized inputs."""
    mu, sd = float(np.mean(y)), float(np.std(y)) or 1.0
    # Tight tolerance and no weight penalty so simple patterns (1,2,3,4,5)
    # come out exact instead of 5.9999.
    model = MLPRegressor(hidden_layer_sizes=(16, 16), max_iter=2000,
                         random_state=0, solver="lbfgs", tol=1e-12, alpha=0.0)
    import warnings
    from sklearn.exceptions import ConvergenceWarning
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)  # fine for a quick forecast
        model.fit((X - mu) / sd, (y - mu) / sd)
    return model, mu, sd


def _neural_step(model, mu, sd, recent):
    features = (np.asarray(recent, dtype=float) - mu) / sd
    return float(model.predict(features.reshape(1, -1))[0]) * sd + mu


def run_neural_core(csv_data, column, steps):
    """
    Learns how the series changes from its previous values (row order = time),
    then predicts the next `steps` numbers. Every prediction is fed back in as
    input for the following one. Working on the change between consecutive
    values lets the network continue trends beyond the observed range
    (1,2,3,4,5 -> 6,7,8).
    """
    df = read_csv_df(csv_data)

    if column:
        if column not in df.columns:
            raise ValueError(f"Column '{column}' not found in CSV.")
        col = column
    else:
        col = first_numeric_column(df)
        if col is None:
            raise ValueError("No numeric column found in the CSV.")

    series = pd.to_numeric(df[col], errors="coerce").dropna().to_numpy(dtype=float)
    if len(series) < 4:
        raise ValueError(f"Need at least 4 numeric values in '{col}' to train the neural network.")
    series = series[-NEURAL_MAX_TRAIN_ROWS:]
    n = len(series)

    deltas = np.diff(series)
    lags = max(1, min(3, n - 3))  # keeps at least 2 training examples

    # --- Quick accuracy check: one-step-ahead predictions on the last few rows
    holdout = max(1, min(5, n // 5)) if n >= 8 else 0
    check = None
    if holdout:
        d_train = deltas[:len(deltas) - holdout]
        X, y = _neural_windows(d_train, lags)
        if len(y) >= 2:
            m, mu, sd = _fit_neural(X, y)
            actual, predicted = [], []
            for i in range(len(d_train), len(deltas)):
                prev = series[i]  # last known value before this step
                predicted.append(prev + _neural_step(m, mu, sd, deltas[i - lags:i]))
                actual.append(series[i + 1])
            check = {
                "actual": np.array(actual), "predicted": np.array(predicted),
                "mae": float(mean_absolute_error(actual, predicted)),
                "rmse": float(np.sqrt(mean_squared_error(actual, predicted))),
            }

    # --- Final model on all data (this is the timed part)
    t0 = time.perf_counter()
    X, y = _neural_windows(deltas, lags)
    model, mu, sd = _fit_neural(X, y)
    train_seconds = time.perf_counter() - t0

    t1 = time.perf_counter()
    history = list(deltas)
    last = float(series[-1])
    forecast = []
    for _ in range(steps):
        delta = _neural_step(model, mu, sd, history[-lags:])
        last += delta
        history.append(delta)          # the prediction becomes input
        forecast.append(last)
    predict_ms = (time.perf_counter() - t1) * 1000

    return {
        "column": col, "series": series, "forecast": forecast, "lags": lags,
        "rows": n, "train_seconds": train_seconds, "predict_ms": predict_ms,
        "check": check,
    }


def chart_neural_forecast(series, forecast, column):
    n = len(series)
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=list(range(1, n + 1)), y=list(series), mode="lines+markers",
        name="Previous values", line=dict(color="#2563eb"), marker=dict(size=7)))
    fig.add_trace(go.Scatter(
        x=[n] + list(range(n + 1, n + len(forecast) + 1)),
        y=[float(series[-1])] + list(forecast), mode="lines+markers",
        name="Neural network prediction",
        line=dict(color="#16a34a", dash="dash"), marker=dict(size=8)))
    fig.update_layout(title=f"{column} — Next Values (Neural Network)",
                      xaxis_title="Row (time step)", yaxis_title=column,
                      **CHART_LAYOUT_DEFAULTS)
    return fig.to_dict()


def pdf_neural_forecast(series, forecast, column):
    n = len(series)
    fig, ax = plt.subplots(figsize=(8, 4.4))
    ax.plot(range(1, n + 1), series, marker="o", label="Previous values")
    ax.plot([n] + list(range(n + 1, n + len(forecast) + 1)),
            [float(series[-1])] + list(forecast), marker="o", linestyle="--",
            label="Neural network prediction")
    ax.set_title(f"{column} — Next Values (Neural Network)")
    ax.set_xlabel("Row (time step)"); ax.set_ylabel(column); ax.legend()
    return _png_from_matplotlib(fig)


def _neural_check_line(check):
    if check is None:
        return None
    return (f"Accuracy check (one step ahead on the last {len(check['actual'])} row(s)): "
            f"MAE {check['mae']:.4f}, RMSE {check['rmse']:.4f}")


@app.route("/neural", methods=["POST"])
def neural():
    try:
        data = request.get_json()
        csv_data = data.get("csv")
        if not csv_data:
            return jsonify({"message": "Paste CSV data."}), 400

        steps = parse_neural_steps(data.get("steps"))
        r = run_neural_core(csv_data, (data.get("column") or "").strip(), steps)

        metrics = [
            ("Rows Used", f"{r['rows']}"),
            ("Previous Values Used", f"{r['lags']}"),
            ("Training Time", f"{r['train_seconds']:.3f} s"),
            ("Prediction Time", f"{r['predict_ms']:.2f} ms"),
        ]
        if r["check"]:
            metrics += [("Check MAE", f"{r['check']['mae']:.4f}"),
                        ("Check RMSE", f"{r['check']['rmse']:.4f}")]

        rows_html = "".join(
            f"<tr><td style='padding:6px; border-bottom:1px solid #e2e8f0;'>Next +{i}</td>"
            f"<td style='padding:6px; border-bottom:1px solid #e2e8f0;'>{v:.4f}</td></tr>"
            for i, v in enumerate(r["forecast"], 1))

        msg = "Neural Network Completed Successfully<br><br>"
        msg += f"<b>Column:</b> {r['column']}<br>"
        msg += metric_cards_html(metrics)
        msg += (
            "<div style='margin-top:6px; padding:16px; background:#f8fafc; "
            "border-left:4px solid #1b2328; border-radius:8px;'>"
            "<div style='font-size:20px; font-weight:bold; color:#1e293b;'>"
            f"Predicted Next Value: {r['forecast'][0]:.4f}</div>"
            "<div style='font-size:12px; color:#64748b; margin:6px 0 10px;'>"
            f"A small neural network (scikit-learn) learned from the last {r['lags']} change(s) "
            "of your values. Each prediction is fed back in to predict the next, so errors can "
            "build up in later steps.</div>"
            "<table style='width:100%; border-collapse:collapse;'>"
            "<tr><th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>Step</th>"
            f"<th style='text-align:left; border-bottom:2px solid #1e293b; padding:6px;'>Predicted {r['column']}</th></tr>"
            f"{rows_html}</table></div>")
        if r["check"] is None:
            msg += ("<p style='margin-top:10px; font-size:12px; color:#64748b;'>"
                    "Accuracy check skipped: it needs at least 8 values.</p>")

        return jsonify({
            "message": msg,
            "charts": [{"id": "neural-forecast-chart",
                        "figure": chart_neural_forecast(r["series"], r["forecast"], r["column"])}],
        })

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Neural Error", e)
        return jsonify({"message": f"Neural Network Error: {str(e)}"}), 500


@app.route("/neural/report", methods=["POST"])
def neural_report():
    try:
        data = request.get_json()
        csv_data = data.get("csv")
        if not csv_data:
            return jsonify({"message": "Missing CSV."}), 400

        steps = parse_neural_steps(data.get("steps"))
        r = run_neural_core(csv_data, (data.get("column") or "").strip(), steps)

        meta_lines = [
            "<b>Model:</b> Neural Network (scikit-learn MLPRegressor, 2 hidden layers of 16)",
            f"<b>Column:</b> {r['column']}",
            f"<b>Rows Used:</b> {r['rows']}",
            f"<b>Previous Values Used per Prediction:</b> {r['lags']}",
            f"<b>Training Time:</b> {r['train_seconds']:.3f} s",
            f"<b>Prediction Time:</b> {r['predict_ms']:.2f} ms",
        ]
        check_line = _neural_check_line(r["check"])
        if check_line:
            meta_lines.append(check_line)

        pdf_buffer = build_pdf(
            title="Neural Network Next-Value Report",
            meta_lines=meta_lines,
            table_headers=["Step", f"Predicted {r['column']}"],
            table_rows=[[f"Next +{i}", f"{v:.4f}"] for i, v in enumerate(r["forecast"], 1)],
            highlight_title="Predicted Next Value",
            highlight_lines=[
                f"{r['forecast'][0]:.4f}",
                "Each prediction is fed back in to predict the following one.",
            ],
            chart_images=[(f"{r['column']} — Next Values (Neural Network)",
                           pdf_neural_forecast(r["series"], r["forecast"], r["column"]))],
        )

        return send_file(pdf_buffer, mimetype="application/pdf", as_attachment=True,
                         download_name="neural_network_report.pdf")

    except ValueError as ve:
        return jsonify({"message": str(ve)}), 400
    except Exception as e:
        print("Neural Report Error", e)
        return jsonify({"message": f"Neural Network Report Error: {str(e)}"}), 500


@app.route("/explain", methods=["POST"])
def explain_result():
    """Explain a result in a few lines using the local small language model
    (falls back to a rule-based summary if the model is not installed)."""
    try:
        import explain
        data = request.get_json(silent=True) or {}
        return jsonify(explain.explain(data.get("kind", ""), data.get("text", "")))
    except Exception as e:
        print("Explain Error", e)
        return jsonify({"message": f"Explain Error: {str(e)}"}), 500


# ---------------------------------------------------------------- updates
# The app runs on the user's own computer, so new versions must be downloaded.
# On start-up the page asks /api/check-update, which reads a small version.json
# file that you host (for example on AWS S3 + CloudFront). Nothing about the
# user's data or account is sent: it is a plain GET of that one file.
APP_VERSION = "1.0.0"          # change this for every release
UPDATE_URL = os.environ.get("CRAZEIT_UPDATE_URL", "")   # e.g. https://updates.yoursite.com/crazeit/version.json
_update_cache = {"time": 0.0, "data": None}


def _version_tuple(v):
    """'1.2.10' -> (1, 2, 10). Non-numeric parts are ignored; bad input -> None."""
    try:
        parts = [int(p) for p in str(v).strip().lstrip("vV").split(".")]
        return tuple(parts) if parts else None
    except (ValueError, TypeError):
        return None


def _fetch_update_info():
    """Download and sanity-check version.json. Returns a dict or None."""
    import json
    import urllib.request
    if not UPDATE_URL.lower().startswith("https://"):
        return None
    req = urllib.request.Request(UPDATE_URL, headers={"User-Agent": "crazeit-update-check"})
    with urllib.request.urlopen(req, timeout=5) as resp:
        raw = resp.read(65536)
    info = json.loads(raw.decode("utf-8-sig"))   # tolerate a BOM from Windows editors
    if not isinstance(info, dict) or _version_tuple(info.get("latest_version")) is None:
        return None
    return info


@app.route("/api/version")
def api_version():
    return jsonify({"version": APP_VERSION})


@app.route("/api/check-update")
def api_check_update():
    """Tells the page whether a newer version exists. Never raises: if the
    update file is not configured or unreachable the answer is simply
    'no update', so the app works offline and without the update server."""
    result = {"current_version": APP_VERSION, "update_available": False}
    try:
        now = time.time()
        if _update_cache["data"] is None or now - _update_cache["time"] > 3600:
            _update_cache["data"] = _fetch_update_info() or {}
            _update_cache["time"] = now
        info = _update_cache["data"]
        if info:
            latest = _version_tuple(info["latest_version"])
            current = _version_tuple(APP_VERSION)
            if latest and current and latest > current:
                url = str(info.get("download_url", ""))
                minimum = _version_tuple(info.get("minimum_version", "0"))
                result.update({
                    "update_available": True,
                    "latest_version": str(info["latest_version"]),
                    "notes": str(info.get("notes", ""))[:600],
                    "download_url": url if url.lower().startswith("https://") else "",
                    "sha256": str(info.get("sha256", ""))[:64],
                    "required": bool(minimum and current < minimum),
                })
    except Exception:
        pass   # offline, DNS failure, bad JSON ... : stay silent
    return jsonify(result)


@app.route("/plotly.min.js")
def plotly_js():
    """Serve Plotly from the installed plotly package so the dashboard
    works offline (used by the desktop build). home.html falls back to the
    CDN if this route is unavailable."""
    import os
    import plotly
    js_path = os.path.join(os.path.dirname(plotly.__file__),
                           "package_data", "plotly.min.js")
    return send_file(js_path, mimetype="application/javascript")


if __name__ == "__main__":
    app.run(debug=True)
