"""Download the small explainer model (~0.4 GB) once.

Usage:  python download_model.py
Saves to ~/.statsdashboard/models/ (the app looks there automatically).
"""
import os
import sys
import urllib.request

import explain

dest_dir = os.path.join(os.path.expanduser("~"), ".statsdashboard", "models")
os.makedirs(dest_dir, exist_ok=True)
dest = os.path.join(dest_dir, explain.MODEL_FILENAME)

if os.path.isfile(dest):
    print("Model already downloaded:", dest)
    sys.exit(0)

tmp = dest + ".part"


def progress(blocks, block_size, total):
    if total > 0:
        pct = min(100, blocks * block_size * 100 // total)
        print(f"\rDownloading... {pct}%", end="", flush=True)


urllib.request.urlretrieve(explain.MODEL_URL, tmp, progress)
os.replace(tmp, dest)
print("\nSaved to", dest)
