"""Local, low-memory result explainer.

Runs a small quantized language model (default: Qwen2.5-0.5B-Instruct, ~0.4 GB)
on the user's own computer, either through llama-cpp-python or through Ollama
(no compiler needed). If neither is available, or the model's answer contains numbers that are not in the real
results, it falls back to a simple rule-based summary, so the button always works.
"""
import os
import re
import sys
import threading

MODEL_FILENAME = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
MODEL_URL = ("https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/"
             + MODEL_FILENAME)

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "qwen2.5:0.5b")

MAX_INPUT_CHARS = 1800
MAX_NEW_TOKENS = 110

_llm = None
_llm_failed = False
_lock = threading.Lock()


# ---------------------------------------------------------------- model files

def _candidate_dirs():
    dirs = []
    env = os.environ.get("EXPLAIN_MODEL_DIR")
    if env:
        dirs.append(env)
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
    dirs.append(os.path.join(base, "models"))
    dirs.append(os.path.join(os.path.expanduser("~"), ".statsdashboard", "models"))
    return dirs


def find_model_path():
    explicit = os.environ.get("EXPLAIN_MODEL_PATH")
    if explicit and os.path.isfile(explicit):
        return explicit
    for d in _candidate_dirs():
        p = os.path.join(d, MODEL_FILENAME)
        if os.path.isfile(p):
            return p
    return None


def get_llm():
    """Load the model once (lazily). Returns None if unavailable."""
    global _llm, _llm_failed
    if _llm is not None or _llm_failed:
        return _llm
    path = find_model_path()
    if not path:
        _llm_failed = True
        return None
    try:
        from llama_cpp import Llama
        _llm = Llama(
            model_path=path,
            n_ctx=1024,          # small context keeps RAM low
            n_threads=max(1, min(4, os.cpu_count() or 2)),
            n_batch=128,
            use_mmap=True,       # lets the OS page the model in/out
            verbose=False,
        )
    except Exception as e:  # missing library, bad file, out of memory ...
        print("Explain model could not be loaded:", e)
        _llm_failed = True
        _llm = None
    return _llm


def model_status():
    return {"model_file_found": find_model_path() is not None,
            "model_loaded": _llm is not None}


def _ollama_chat(messages):
    """Ask a locally running Ollama server. Raises if it isn't running."""
    import json
    import urllib.request
    body = json.dumps({
        "model": OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
        "options": {"temperature": 0.2, "num_predict": MAX_NEW_TOKENS, "num_ctx": 1024},
    }).encode()
    req = urllib.request.Request(OLLAMA_URL + "/api/chat", data=body,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as resp:
        return json.loads(resp.read())["message"]["content"].strip()


# ------------------------------------------------------------------- prompting

KIND_HINTS = {
    "regression": "a regression analysis (R2 close to 1 means a good fit; lower MAE/MSE is better)",
    "multimodel": "a comparison of several regression models (higher R2 is better)",
    "gradient": "a comparison of gradient boosting models (higher R2 is better)",
    "simulation": "a Monte Carlo simulation that predicts the next value",
    "neural": "a neural network that predicts the next numbers of a series from its previous values (a lower check MAE/RMSE is better)",
    "hypothesis": "a hypothesis test (p-value below 0.05 means a significant result)",
}


def build_messages(kind, text):
    hint = KIND_HINTS.get(kind, "a statistical analysis")
    system = ("You explain statistics results to a beginner in 2 to 3 short sentences. "
              "Use ONLY the numbers given. Never invent or calculate new numbers.")
    user = (f"Here are the results of {hint}:\n\n{text}\n\n"
            "Explain what this means in plain English in 2 to 3 sentences.")
    return [{"role": "system", "content": system},
            {"role": "user", "content": user}]


# ------------------------------------------------------------------ safety net

_NUM = re.compile(r"\d+(?:\.\d+)?")


def _norm(n):
    n = n.lstrip("0") if n.startswith("0") and "." not in n and len(n) > 1 else n
    if "." in n:
        n = n.rstrip("0").rstrip(".")
    return n or "0"


def numbers_are_grounded(answer, source):
    """True if every number in the answer also appears in the source text."""
    allowed = {_norm(n) for n in _NUM.findall(source)} | {"0.05", "0.01", "1", "2", "3"}
    return all(_norm(n) in allowed for n in _NUM.findall(answer))


_VALUE_LINE = re.compile(r"^-?\d[\d,]*(?:\.\d+)?%?$|^N/A$", re.I)


def pair_metric_lines(text):
    """Metric cards arrive as 'Label' and 'value' on separate lines; join them
    into 'Label: value' so neither the model nor the fallback loses the number."""
    lines = [ln.strip() for ln in re.split(r"[\n\r]+", text) if ln.strip()]
    out, i = [], 0
    while i < len(lines):
        cur = lines[i]
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        if (not re.search(r"\d", cur) and len(cur) <= 30 and _VALUE_LINE.match(nxt)):
            out.append(f"{cur}: {nxt}")
            i += 2
        else:
            out.append(cur)
            i += 1
    return "\n".join(out)


def _first_number_after(label_pattern, text):
    m = re.search(label_pattern + r"[^0-9\-\n]{0,25}(-?\d+(?:\.\d+)?)", text, re.I)
    return float(m.group(1)) if m else None


def rule_based_summary(text):
    """Simple fallback: keep the most informative lines of the result."""
    text = pair_metric_lines(text)
    sentences = []

    r2 = _first_number_after(r"(?:R²|R2)", text)
    if r2 is not None:
        quality = ("excellent" if r2 >= 0.9 else "good" if r2 >= 0.7
                   else "moderate" if r2 >= 0.4 else "weak")
        sentences.append(
            f"R² is {r2:g}, so the model explains about {r2 * 100:.1f}% of the "
            f"variation in the target ({quality} fit).")
        mae = _first_number_after(r"\bMAE\b", text)
        if mae is not None:
            sentences.append(f"On average its predictions are off by {mae:g} (MAE).")

    pred = _first_number_after(r"predicted next(?: value)?", text)
    if pred is not None:
        sentences.append(f"The predicted next value is about {pred:g}.")

    m = re.search(r"Conclusion:?\s*(.+)", text, re.I)
    if m:
        sentences.append(m.group(1).strip())

    if sentences:
        return " ".join(sentences)[:500]

    keys = ("best model", "predicted", "p-value", "mean")
    lines = text.split("\n")
    picked = [ln for ln in lines if any(k in ln.lower() for k in keys)] or lines
    return " ".join(picked[:3])[:400] or "No result text to explain yet."


# ---------------------------------------------------------------------- public

def explain(kind, text):
    """Return {"explanation": str, "source": "llm" | "rules", "reason": ...}."""
    text = pair_metric_lines((text or "").strip())[:MAX_INPUT_CHARS]
    if not text:
        return {"explanation": "Run an analysis first, then ask for an explanation.",
                "source": "rules"}

    messages = build_messages(kind, text)
    answer, reason = None, "no_model"

    with _lock:
        llm = get_llm()
        if llm is not None:
            try:
                out = llm.create_chat_completion(
                    messages=messages, max_tokens=MAX_NEW_TOKENS,
                    temperature=0.2, top_p=0.9)
                answer = out["choices"][0]["message"]["content"].strip()
            except Exception as e:
                print("Explain generation failed:", e)

        if answer is None:
            try:
                answer = _ollama_chat(messages)
            except Exception:
                answer = None  # Ollama not running / model not pulled

    if answer:
        if numbers_are_grounded(answer, text):
            return {"explanation": answer, "source": "llm"}
        reason = "rejected"

    return {"explanation": rule_based_summary(text), "source": "rules", "reason": reason}
